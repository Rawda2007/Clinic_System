﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clinic_triage_system
{
    //enum status
    //{
    //    Add=1,
    //    Update=2,
    //    Remove=3,
    //}
     class TriageResult<T>
    {
        public T PatientId { get; set; }
        //string Name { get; set; }
        public int Priority { get; set; }
        public TriageResult(T PatientId,int Priority) 
        { 
            this.PatientId = PatientId;
            //this.Name = Name;
            this.Priority = Priority;
        }
    }

    class TriageSystem
    {
        
        Dictionary<int,string> patients = new Dictionary<int,string>();
        Queue<int> IDs = new Queue<int>();
        Stack<string> Actions = new Stack<string>();

        public void AddPatient(int id, string name)
        {
          patients.Add(id, name);
          IDs.Enqueue(id);
          Actions.Push($"Added patient {id} with name {name}");
          Console.WriteLine(Actions.Peek());
        }
        public string GetPatientName(int id)
        {
            if (patients.TryGetValue(id, out string value))
            {
                return value;
            }
                return "Not Found ID";
        }
        public void ProcessNextPatient()
        {
            if (IDs.Count > 0)
            {
                int id = IDs.Dequeue();
                patients.Remove(id);
                
            }
            
        }
        public void UpdatePatient(int id, string newName)
        {
            if (patients.ContainsKey(id))
            {
                patients[id] = newName;
                Actions.Push($"Updated patient {id} to {newName}");
                Console.WriteLine(Actions.Peek());
            }
            else
            {
                Console.WriteLine($"Patient with ID {id} not found.");
            }
        }
         public void RemovePatient(int id)
        {
            if (patients.ContainsKey(id))
            {
                patients.Remove(id);
                Actions.Push($"Removed patient {id}");
                Console.WriteLine(Actions.Peek());

            }
            else
            {
                Console.WriteLine($"Patient with ID {id} not found.");
            }
        }
        public void Undo()
        {
            patients.Remove(patients.Count-1);
            //ازايQueue مش عارفه احذف اخر عمليه من ال 
            Actions.Pop();
        }

        internal Queue<int> GetIDs()
        {
            return IDs;
        }

        //Require (6)
        public Tuple<int, string> GetNextPatient()
        {
            if (IDs.Count > 0)
            {
                int id = IDs.Peek();
                string name = patients[id];
                return Tuple.Create(id, name);
            }
            else
            {
                return null;
            }
        }

        public void SortedPatientList()
        {
            SortedList<int, string> sortedPatients = new SortedList<int, string>();
            foreach (var id in GetIDs())
            {
                sortedPatients.Add(id, patients[id]);
            }
           Console.WriteLine("Sorted Patient List:");
            foreach (var kvp in sortedPatients)
            {
                Console.WriteLine($"Patient ID: {kvp.Key}, Name: {kvp.Value}");
            }
        }

    }
    class PatientList
    {
        private TriageSystem triageSystem; 

        public PatientList(TriageSystem system)
        {
            triageSystem = system; 
        }

        // indexer
        public string this[int id]
        {
            get { return triageSystem.GetPatientName(id); }
        }

        // عرض كل المرضى
        public void DisplayIDsPatients()
        {
            foreach (int id in triageSystem.GetIDs())
            {
                Console.WriteLine($"Patient ID: {id}, Name: {this[id]}");
            }
        }
        public void PatientListbyManuallyIEnumerator()
        {
            IEnumerator<int> enumerator = triageSystem.GetIDs().GetEnumerator();
            while (enumerator.MoveNext())
            {
                int id = enumerator.Current;
                Console.WriteLine($"Patient ID: {id}, Name: {this[id]}");
            }
        }
    }

   
    internal class Program
    {
        static void Main(string[] args)
        {
            TriageSystem patients = new TriageSystem();
            patients.AddPatient(3, "Ali");
            patients.AddPatient(2, "Jana");
            patients.AddPatient(1, "Omar");
            Console.WriteLine(patients.GetPatientName(2));
            Console.WriteLine(patients.GetPatientName(3));
            patients.SortedPatientList();
            patients.ProcessNextPatient();
            PatientList patientList = new PatientList(patients);
            Console.WriteLine(patientList[3]);
            patientList.DisplayIDsPatients();
            patientList.PatientListbyManuallyIEnumerator();
        }
    }
}
